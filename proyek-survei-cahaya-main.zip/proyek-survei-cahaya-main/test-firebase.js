import { deleteFileFromStorage } from './app/lib/firebase-admin.js';

async function testDeleteFile(filePath) {
  try {
    console.log(`Testing deletion of file: ${filePath}`);
    await deleteFileFromStorage(filePath);
    console.log('File deletion test completed.');
  } catch (error) {
    console.error('Error during file deletion test:', error);
  }
}

// Replace with an actual file path from your Firebase Storage to test
const testFilePath = 'petugas-photos/your-test-file.webp';

testDeleteFile(testFilePath);
