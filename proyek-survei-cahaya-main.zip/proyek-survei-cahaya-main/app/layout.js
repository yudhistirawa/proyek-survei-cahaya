// app/layout.js
import { Roboto_Flex } from 'next/font/google';
import './globals.css';
import Script from 'next/script';

// Konfigurasi font Roboto Flex
const robotoFlex = Roboto_Flex({
  subsets: ['latin'],
  variable: '--font-roboto-flex', // Menetapkan variabel CSS untuk font
});

export const metadata = {
  title: 'Dashboard Pengukuran',
  description: 'Aplikasi untuk pengukuran dan pelaporan intensitas cahaya.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      {/* Terapkan font ke seluruh aplikasi melalui `body` */}
      <body className={`${robotoFlex.variable} font-sans`}>
        {children}
        
        {/* Memuat library eksternal */}
        <Script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js" strategy="lazyOnload" id="jszip-script" />
        <Script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js" strategy="lazyOnload" id="filesaver-script" />
        <Script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js" strategy="lazyOnload" id="xlsx-script" />
      </body>
    </html>
  );
}
