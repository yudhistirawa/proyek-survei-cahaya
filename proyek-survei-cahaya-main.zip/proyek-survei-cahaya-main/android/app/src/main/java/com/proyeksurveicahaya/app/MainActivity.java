package com.proyeksurveicahaya.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
