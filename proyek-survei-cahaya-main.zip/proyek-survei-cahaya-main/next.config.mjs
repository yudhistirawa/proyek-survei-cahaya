/** @type {import('next').NextConfig} */
const nextConfig = {};

// SINTAKS BARU (ES Modules)
export default nextConfig;